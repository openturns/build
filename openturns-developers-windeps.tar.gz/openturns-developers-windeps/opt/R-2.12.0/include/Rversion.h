/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 134144
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "2"
#define R_MINOR  "12.0"
#define R_STATUS ""
#define R_YEAR   "2010"
#define R_MONTH  "10"
#define R_DAY    "15"
#define R_SVN_REVISION "53317"
#define R_FILEVERSION    2,120,53317,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
